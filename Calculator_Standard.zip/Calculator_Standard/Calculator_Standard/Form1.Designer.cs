﻿namespace Calculator_Standard
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.CB1 = new System.Windows.Forms.Button();
            this.CB2 = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.backspace = new System.Windows.Forms.Button();
            this.div = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.mal = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.sub = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Button();
            this.point = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.textBoxOut = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.b4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CB1
            // 
            this.CB1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CB1.Image = ((System.Drawing.Image)(resources.GetObject("CB1.Image")));
            this.CB1.Location = new System.Drawing.Point(21, 205);
            this.CB1.Name = "CB1";
            this.CB1.Size = new System.Drawing.Size(117, 55);
            this.CB1.TabIndex = 0;
            this.CB1.UseVisualStyleBackColor = true;
            // 
            // CB2
            // 
            this.CB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CB2.Image = ((System.Drawing.Image)(resources.GetObject("CB2.Image")));
            this.CB2.Location = new System.Drawing.Point(171, 205);
            this.CB2.Name = "CB2";
            this.CB2.Size = new System.Drawing.Size(117, 55);
            this.CB2.TabIndex = 1;
            this.CB2.UseVisualStyleBackColor = true;
            this.CB2.Click += new System.EventHandler(this.CB2_Click);
            // 
            // clear
            // 
            this.clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clear.Image = ((System.Drawing.Image)(resources.GetObject("clear.Image")));
            this.clear.Location = new System.Drawing.Point(312, 205);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(117, 55);
            this.clear.TabIndex = 2;
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.CB3_Click);
            // 
            // backspace
            // 
            this.backspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backspace.Image = ((System.Drawing.Image)(resources.GetObject("backspace.Image")));
            this.backspace.Location = new System.Drawing.Point(455, 205);
            this.backspace.Name = "backspace";
            this.backspace.Size = new System.Drawing.Size(117, 55);
            this.backspace.TabIndex = 3;
            this.backspace.UseVisualStyleBackColor = true;
            // 
            // div
            // 
            this.div.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.div.Image = ((System.Drawing.Image)(resources.GetObject("div.Image")));
            this.div.Location = new System.Drawing.Point(458, 289);
            this.div.Name = "div";
            this.div.Size = new System.Drawing.Size(117, 55);
            this.div.TabIndex = 7;
            this.div.UseVisualStyleBackColor = true;
            this.div.Click += new System.EventHandler(this.div_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(315, 289);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(117, 55);
            this.button2.TabIndex = 6;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(174, 289);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(117, 55);
            this.button3.TabIndex = 5;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(24, 289);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(117, 55);
            this.button4.TabIndex = 4;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // mal
            // 
            this.mal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mal.Image = ((System.Drawing.Image)(resources.GetObject("mal.Image")));
            this.mal.Location = new System.Drawing.Point(455, 386);
            this.mal.Name = "mal";
            this.mal.Size = new System.Drawing.Size(117, 55);
            this.mal.TabIndex = 11;
            this.mal.Text = "\r\n";
            this.mal.UseVisualStyleBackColor = true;
            this.mal.Click += new System.EventHandler(this.mal_Click);
            // 
            // b9
            // 
            this.b9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b9.Image = ((System.Drawing.Image)(resources.GetObject("b9.Image")));
            this.b9.Location = new System.Drawing.Point(312, 386);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(117, 55);
            this.b9.TabIndex = 10;
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // b8
            // 
            this.b8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b8.Image = ((System.Drawing.Image)(resources.GetObject("b8.Image")));
            this.b8.Location = new System.Drawing.Point(171, 386);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(117, 55);
            this.b8.TabIndex = 9;
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.button7_Click);
            // 
            // b7
            // 
            this.b7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b7.Image = ((System.Drawing.Image)(resources.GetObject("b7.Image")));
            this.b7.Location = new System.Drawing.Point(21, 386);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(117, 55);
            this.b7.TabIndex = 8;
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.button8_Click);
            // 
            // sub
            // 
            this.sub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sub.Image = ((System.Drawing.Image)(resources.GetObject("sub.Image")));
            this.sub.Location = new System.Drawing.Point(455, 478);
            this.sub.Name = "sub";
            this.sub.Size = new System.Drawing.Size(117, 55);
            this.sub.TabIndex = 15;
            this.sub.Text = "\r\n";
            this.sub.UseVisualStyleBackColor = true;
            this.sub.Click += new System.EventHandler(this.button9_Click);
            // 
            // b6
            // 
            this.b6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b6.Image = ((System.Drawing.Image)(resources.GetObject("b6.Image")));
            this.b6.Location = new System.Drawing.Point(312, 478);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(117, 55);
            this.b6.TabIndex = 14;
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.button10_Click);
            // 
            // b5
            // 
            this.b5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b5.Image = ((System.Drawing.Image)(resources.GetObject("b5.Image")));
            this.b5.Location = new System.Drawing.Point(171, 478);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(117, 55);
            this.b5.TabIndex = 13;
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.button11_Click);
            // 
            // add
            // 
            this.add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add.Image = ((System.Drawing.Image)(resources.GetObject("add.Image")));
            this.add.Location = new System.Drawing.Point(455, 570);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(117, 55);
            this.add.TabIndex = 19;
            this.add.Text = "\r\n";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // b3
            // 
            this.b3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b3.Image = ((System.Drawing.Image)(resources.GetObject("b3.Image")));
            this.b3.Location = new System.Drawing.Point(312, 570);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(117, 55);
            this.b3.TabIndex = 18;
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.button14_Click);
            // 
            // b2
            // 
            this.b2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b2.Image = ((System.Drawing.Image)(resources.GetObject("b2.Image")));
            this.b2.Location = new System.Drawing.Point(171, 570);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(117, 55);
            this.b2.TabIndex = 17;
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.button15_Click);
            // 
            // b1
            // 
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b1.Image = ((System.Drawing.Image)(resources.GetObject("b1.Image")));
            this.b1.Location = new System.Drawing.Point(21, 570);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(117, 55);
            this.b1.TabIndex = 16;
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.button16_Click);
            // 
            // result
            // 
            this.result.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.result.Image = ((System.Drawing.Image)(resources.GetObject("result.Image")));
            this.result.Location = new System.Drawing.Point(455, 659);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(117, 55);
            this.result.TabIndex = 23;
            this.result.Text = "\r\n";
            this.result.UseVisualStyleBackColor = true;
            this.result.Click += new System.EventHandler(this.button17_Click);
            // 
            // point
            // 
            this.point.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.point.Image = ((System.Drawing.Image)(resources.GetObject("point.Image")));
            this.point.Location = new System.Drawing.Point(312, 659);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(117, 55);
            this.point.TabIndex = 22;
            this.point.UseVisualStyleBackColor = true;
            // 
            // b0
            // 
            this.b0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b0.Image = ((System.Drawing.Image)(resources.GetObject("b0.Image")));
            this.b0.Location = new System.Drawing.Point(171, 659);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(117, 55);
            this.b0.TabIndex = 21;
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Image = ((System.Drawing.Image)(resources.GetObject("button20.Image")));
            this.button20.Location = new System.Drawing.Point(21, 659);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(117, 55);
            this.button20.TabIndex = 20;
            this.button20.UseVisualStyleBackColor = true;
            // 
            // textBoxOut
            // 
            this.textBoxOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 38F);
            this.textBoxOut.Location = new System.Drawing.Point(24, 90);
            this.textBoxOut.Name = "textBoxOut";
            this.textBoxOut.Size = new System.Drawing.Size(554, 94);
            this.textBoxOut.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(27, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 32);
            this.label1.TabIndex = 25;
            this.label1.Text = "Calculator";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // b4
            // 
            this.b4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b4.Image = ((System.Drawing.Image)(resources.GetObject("b4.Image")));
            this.b4.Location = new System.Drawing.Point(21, 478);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(117, 55);
            this.b4.TabIndex = 12;
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.button12_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(596, 725);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxOut);
            this.Controls.Add(this.result);
            this.Controls.Add(this.point);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.add);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.sub);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.mal);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.div);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.backspace);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.CB2);
            this.Controls.Add(this.CB1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CB1;
        public System.Windows.Forms.Button CB2;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button backspace;
        private System.Windows.Forms.Button div;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button mal;
        private System.Windows.Forms.Button b9;
        public System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button sub;
        private System.Windows.Forms.Button b6;
        public System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button b3;
        public System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button result;
        private System.Windows.Forms.Button point;
        public System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox textBoxOut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button b4;
    }
}

